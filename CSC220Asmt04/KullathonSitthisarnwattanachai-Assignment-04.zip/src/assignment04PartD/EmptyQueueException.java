package assignment04PartD;

/**
 *
 * Part D
 *
 */

public class EmptyQueueException extends RuntimeException
{
	
} // end EmptyQueueException